import { Injectable, StreamableFile } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { In, IntegerType, Repository } from 'typeorm';
import { CreateUserDto } from '../dtos/CreateUser.dto';
import { TestTable, UserTable } from 'src/typeorm';
import { CreateTestDto } from 'src/dtos/CreateTest.dto';
import { diskStorage } from 'multer';
import { UserService } from 'src/user/user.service';
import { createReadStream } from 'fs';
import { join } from 'path';
import { AppDataSource } from 'src/typeorm/DataSource';
import { spawnSync } from 'child_process';
//import 

@Injectable()
export class TestService {
  constructor(private userService:UserService,
    @InjectRepository(TestTable) private readonly testRepository: Repository<TestTable>){}

  async getTestData(id:string){
    const test= await this.testRepository.findOneBy({id})
    //const reply = { name: test.name, url: test.url, success_rate: test.success_rate, time_spent: test.time_spent }
    return test
  }

  async deleteTest(id:string, session:Record<string,any>){
    const test = await AppDataSource.getRepository(TestTable).createQueryBuilder('test').select().where("id=:id",{id:id}).leftJoinAndSelect('test.user','user').where('user_id=:id',{id:session.passport.user.id}).getOne()
    if(test||session.passport.user.id==1){
      await AppDataSource.createQueryBuilder().delete().from(TestTable).where('id=:id',{id:id}).execute()
      return true
    }
    return false
  }

  async getUserTests(id){
    const arr = await AppDataSource.getRepository(TestTable).createQueryBuilder('test').leftJoinAndSelect('test.user','user').where('user.id=:id',{id:id}).getMany()
    const ids=[]
    const names = []
    const dates = []
    arr.map((e)=>{
      names.push(e.name)
      ids.push(e.id)
      dates.push(e.creation_date)
    })
    return {names:names,ids:ids,dates:dates}
  }

  async createTest(params:any, session: Record<string,any>){
    let createTestDto = new CreateTestDto()
    const user = await AppDataSource.getRepository(UserTable).findOneBy({id:session.passport.user.id})
    createTestDto.name = params.name
    createTestDto.url = params.url
    createTestDto.time_spent = '00:00:00'
    createTestDto.fc_accuracy = 0
    createTestDto.user = user.id
    //execute python here
    // доделать асинхронную обработку странички (возвращаем вустую запись, после обработки обновляем бд)
    const { spawn } = require('node:child_process');
    const childPython = spawnSync('python', ["C://Users//deez//Desktop//kursach-main//back//src//test//script.py", 'https://github.com/nodejs/node/issues/14917']);
    console.log(`stdout: ${childPython.stdout}`);

    //const newTest = await this.testRepository.create(createTestDto)
    //return this.testRepository.save(newTest)
  }
}
