import { isNotEmpty, IsNotEmpty } from "class-validator";
import { UserTable } from "src/typeorm";
import { IntegerType } from "typeorm";


export class CreateTestDto{
    @IsNotEmpty()
    name:string

    @IsNotEmpty()
    success_rate:number

    @IsNotEmpty()
    url:string

    @IsNotEmpty()
    time_spent:string

    @IsNotEmpty()
    fc_accuracy:number

    @IsNotEmpty()
    user
}