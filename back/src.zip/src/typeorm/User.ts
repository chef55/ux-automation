import { Column, Entity, OneToMany, PrimaryGeneratedColumn } from "typeorm";
import { TestTable } from "./Test";

@Entity()
export class UserTable{
    @PrimaryGeneratedColumn({
        type: 'bigint',
        name:'user_id',
    })
    id:string;

    @Column()
    email:string;

    @Column()
    username:string;

    @Column()
    password:string;

    @OneToMany(()=>TestTable, (test)=>test.user)
    tests: TestTable[]
}