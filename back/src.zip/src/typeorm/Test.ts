import { Column, CreateDateColumn, Entity, Index, IsNull, ManyToOne, OneToMany, OneToOne, PrimaryGeneratedColumn } from "typeorm";
import { UserTable } from "./User";

@Entity()
export class TestTable{
    @PrimaryGeneratedColumn({
        type: 'bigint',
        name:'test_id',
    })
    id:string;

    @Column('varchar')
    name='';

    @Column('varchar')
    url='';

    @Column('integer')
    success_rate=0;

    @Column('time')
    time_spent='00:00:00';

    @Column('integer')
    fc_accuracy=0;

    @CreateDateColumn()
    creation_date

    @Column('bigint')
    expiredAt=Date.now()+31557600000

    @ManyToOne(()=>UserTable, (user)=>user.tests, { onDelete: 'CASCADE' })
    user: UserTable
}