import { TestTable } from "./Test";
import { SessionTable } from "./Session";
import { UserTable } from "./User";

const entities = [UserTable, TestTable, SessionTable]
export {UserTable, TestTable, SessionTable}

export default entities